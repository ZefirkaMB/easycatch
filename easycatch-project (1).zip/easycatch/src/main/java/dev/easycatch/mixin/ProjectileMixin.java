package dev.easycatch.mixin;

import dev.easycatch.EasyCatchConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Only makes the hit areas bigger. Every hit is then handled by the normal vanilla code
 * (vanilla onHit): the pearl teleports its owner, the wind charge explodes like normal.
 */
@Mixin(Projectile.class)
public abstract class ProjectileMixin {

    @Shadow
    protected abstract void onHit(HitResult result);

    @Shadow
    public abstract Entity getOwner();

    /** true once the pearl has left the owner's (enlarged) hitbox, like vanilla's "leftOwner" */
    @Unique
    private boolean easycatch$leftOwner = false;

    @Inject(method = "tick", at = @At("TAIL"))
    private void easycatch$tick(CallbackInfo ci) {
        if (!EasyCatchConfig.enabled) {
            return;
        }
        Entity self = (Entity) (Object) this;
        if (self.isRemoved() || !(self.level() instanceof ServerLevel)) {
            return;
        }
        EntityType<?> type = self.getType();
        if (type == EntityType.ENDER_PEARL) {
            easycatch$pearl(self);
        } else if (type == EntityType.WIND_CHARGE) {
            easycatch$windCharge(self);
        }
    }

    /** Bigger pearl hitbox: pearl touches its owner -> normal vanilla pearl hit (teleport to the pearl). */
    @Unique
    private void easycatch$pearl(Entity self) {
        double scale = EasyCatchConfig.pearlHitboxScale;
        if (scale <= 1.0) {
            return;
        }
        Entity owner = this.getOwner();
        if (!(owner instanceof Player) || owner.isRemoved()) {
            return;
        }
        double grow = self.getBbWidth() * (scale - 1.0) / 2.0;
        AABB base = self.getBoundingBox().inflate(grow);
        AABB ownerBox = owner.getBoundingBox();

        if (!this.easycatch$leftOwner) {
            if (!base.intersects(ownerBox)) {
                this.easycatch$leftOwner = true;
            }
            return;
        }
        if (base.expandTowards(self.getDeltaMovement()).intersects(ownerBox)) {
            this.onHit(new EntityHitResult(owner));
        }
    }

    /**
     * Bigger wind charge + bigger pearl hitbox: when they overlap, the wind charge hits the pearl
     * exactly like in vanilla (explosion at the contact point on the pearl's surface).
     */
    @Unique
    private void easycatch$windCharge(Entity self) {
        double windScale = Math.max(1.0, EasyCatchConfig.windChargeHitboxScale);
        double pearlScale = Math.max(1.0, EasyCatchConfig.pearlHitboxScale);
        if (windScale <= 1.0 && pearlScale <= 1.0) {
            return;
        }
        double windGrow = self.getBbWidth() * (windScale - 1.0) / 2.0;
        double pearlGrow = 0.25 * (pearlScale - 1.0) / 2.0;
        AABB windBox = self.getBoundingBox().inflate(windGrow).expandTowards(self.getDeltaMovement());

        List<Entity> pearls = self.level().getEntities(self, windBox.inflate(pearlGrow), e ->
                e.getType() == EntityType.ENDER_PEARL && !e.isRemoved());
        for (Entity pearl : pearls) {
            AABB realBox = pearl.getBoundingBox();
            if (windBox.intersects(realBox.inflate(pearlGrow))) {
                Vec3 p = self.position();
                Vec3 hit = new Vec3(
                        Math.max(realBox.minX, Math.min(p.x, realBox.maxX)),
                        Math.max(realBox.minY, Math.min(p.y, realBox.maxY)),
                        Math.max(realBox.minZ, Math.min(p.z, realBox.maxZ)));
                this.onHit(new EntityHitResult(pearl, hit));
                return;
            }
        }
    }
}
