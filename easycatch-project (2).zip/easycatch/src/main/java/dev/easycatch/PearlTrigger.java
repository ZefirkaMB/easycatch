package dev.easycatch;

/** Implemented (via mixin) by every Projectile; lets a wind charge trigger its owner's pearl. */
public interface PearlTrigger {
    void easycatch$trigger();
}
