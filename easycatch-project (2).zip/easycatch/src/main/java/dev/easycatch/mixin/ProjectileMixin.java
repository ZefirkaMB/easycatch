package dev.easycatch.mixin;

import dev.easycatch.EasyCatchConfig;
import dev.easycatch.PearlTrigger;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Bigger hit areas for pearl and wind charge.
 * (vanilla onHit): the pearl teleports its owner, the wind charge explodes like normal.
 */
@Mixin(Projectile.class)
public abstract class ProjectileMixin implements PearlTrigger {

    @Shadow
    protected abstract void onHit(HitResult result);

    @Shadow
    public abstract Entity getOwner();

    /** true once the pearl has left the owner's (enlarged) hitbox, like vanilla's "leftOwner" */
    @Unique
    private boolean easycatch$leftOwner = false;

    /** Teleports the pearl's owner to this pearl (same as the pearl hitting its owner). */
    @Override
    public void easycatch$trigger() {
        Entity self = (Entity) (Object) this;
        Entity owner = this.getOwner();
        if (owner != null && !self.isRemoved() && !owner.isRemoved()) {
            this.onHit(new EntityHitResult(owner));
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void easycatch$tick(CallbackInfo ci) {
        if (!EasyCatchConfig.enabled) {
            return;
        }
        Entity self = (Entity) (Object) this;
        if (self.isRemoved() || !(self.level() instanceof ServerLevel)) {
            return;
        }
        EntityType<?> type = self.getType();
        if (type == EntityType.ENDER_PEARL) {
            easycatch$pearl(self);
        } else if (type == EntityType.WIND_CHARGE) {
            easycatch$windCharge(self);
        }
    }

    /** Bigger pearl hitbox: pearl touches its owner -> normal vanilla pearl hit (teleport to the pearl). */
    @Unique
    private void easycatch$pearl(Entity self) {
        double scale = EasyCatchConfig.pearlHitboxScale;
        if (scale <= 1.0) {
            return;
        }
        Entity owner = this.getOwner();
        if (!(owner instanceof Player) || owner.isRemoved()) {
            return;
        }
        double grow = self.getBbWidth() * (scale - 1.0) / 2.0;
        AABB base = self.getBoundingBox().inflate(grow);
        AABB ownerBox = owner.getBoundingBox();

        if (!this.easycatch$leftOwner) {
            if (!base.intersects(ownerBox)) {
                this.easycatch$leftOwner = true;
            }
            return;
        }
        if (base.expandTowards(self.getDeltaMovement()).intersects(ownerBox)) {
            this.onHit(new EntityHitResult(owner));
        }
    }

    /**
     * Bigger wind charge + bigger pearl hitbox: when the wind charge reaches the owner's own pearl,
     * the owner is teleported to that pearl. The wind charge disappears without exploding,
     * so the pearl is NOT knocked away.
     */
    @Unique
    private void easycatch$windCharge(Entity self) {
        Entity owner = this.getOwner();
        if (!(owner instanceof Player) || owner.isRemoved()) {
            return;
        }
        double windScale = Math.max(1.0, EasyCatchConfig.windChargeHitboxScale);
        double pearlScale = Math.max(1.0, EasyCatchConfig.pearlHitboxScale);
        double windGrow = self.getBbWidth() * (windScale - 1.0) / 2.0;
        double pearlGrow = 0.25 * (pearlScale - 1.0) / 2.0;
        AABB windBox = self.getBoundingBox().inflate(windGrow).expandTowards(self.getDeltaMovement());

        List<Entity> pearls = self.level().getEntities(self, windBox.inflate(pearlGrow), e ->
                e.getType() == EntityType.ENDER_PEARL
                        && !e.isRemoved()
                        && e instanceof Projectile p
                        && p.getOwner() == owner);
        for (Entity pearl : pearls) {
            if (windBox.intersects(pearl.getBoundingBox().inflate(pearlGrow))) {
                ((PearlTrigger) (Object) pearl).easycatch$trigger();
                self.discard();
                return;
            }
        }
    }
}
